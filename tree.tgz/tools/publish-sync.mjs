#!/usr/bin/env node
/**
 * 发布流水线（两仓模型）：个人研发仓 → 脱敏发布仓。
 *
 * 用法：
 *   node tools/publish-sync.mjs --version 0.13.7 [--publish <发布仓路径>] [--no-tag]
 *
 * 做了什么：
 *   1. 从当前仓库 HEAD 导出文件树（git archive）；
 *   2. 按 tools/publish-exclude.txt 去掉"只在个人仓里、不发布"的文件（如 tools/）；
 *   3. 在导出目录上跑 scripts/privacy-check.mjs（带本机黑名单），命中即中止；
 *   4. 把导出内容同步进发布仓（保留发布仓 .git），提交 "dsh-remote <version>"；
 *   5. 打 tag v<version>。
 *
 * 设计原则：
 *   - 发布仓的每个提交都是一个干净快照；历史按 release 累积，可看 diff；
 *   - 扫描不通过时**不改动发布仓**；
 *   - 本脚本只存在于个人仓（被排除在发布之外），不会出现在公开仓库。
 */

import { execFileSync } from "node:child_process";
import { cpSync, existsSync, mkdtempSync, readFileSync, readdirSync, rmSync, statSync } from "node:fs";
import { tmpdir } from "node:os";
import { join, resolve } from "node:path";

function arg(name, fallback) {
	const index = process.argv.indexOf(`--${name}`);
	if (index >= 0 && process.argv[index + 1] !== undefined) return process.argv[index + 1];
	return fallback;
}
function flag(name) {
	return process.argv.includes(`--${name}`);
}

const PERSONAL = resolve(process.cwd());
const VERSION = arg("version", "");
const PUBLISH = resolve(arg("publish", join(PERSONAL, "..", "dsh-remote-clean")));
const EXCLUDE_FILE = join(PERSONAL, "tools", "publish-exclude.txt");

if (VERSION === "" || !/^\d+\.\d+\.\d+$/u.test(VERSION)) {
	console.error("publish-sync: 需要 --version x.y.z");
	process.exit(2);
}
if (!existsSync(join(PERSONAL, ".git")) || !existsSync(join(PUBLISH, ".git"))) {
	console.error("publish-sync: 个人仓或发布仓不是 git 仓库");
	process.exit(2);
}

function git(cwd, args, options = {}) {
	return execFileSync("git", args, { cwd, encoding: "utf8", maxBuffer: 64 * 1024 * 1024, ...options });
}

// 0) 个人仓必须干净（否则导出的不是确定的快照）
const dirty = git(PERSONAL, ["status", "--porcelain"]).trim();
if (dirty !== "") {
	console.error("publish-sync: 个人仓有未提交改动，先提交再发布：");
	console.error(dirty.split("\n").slice(0, 10).join("\n"));
	process.exit(2);
}

// 1) 导出
const work = mkdtempSync(join(tmpdir(), "dsh-publish-"));
const tarball = join(work, "tree.tgz");
try {
	git(PERSONAL, ["archive", "--format=tgz", "-o", tarball, "HEAD"]);
	execFileSync("tar", ["-xzf", tarball, "-C", work], { stdio: "pipe" });

	// 2) 排除个人文件
	if (existsSync(EXCLUDE_FILE)) {
		const excludes = readFileSync(EXCLUDE_FILE, "utf8")
			.split(/\r?\n/u)
			.map((line) => line.trim())
			.filter((line) => line !== "" && !line.startsWith("#"));
		for (const rel of excludes) {
			rmSync(join(work, rel), { recursive: true, force: true });
		}
	}

	// 3) 脱敏检查（在导出目录上再扫一次，且用 git 不跟踪的目录模式）
	const check = execFileSync(process.execPath, [join(work, "scripts", "privacy-check.mjs"), work], {
		encoding: "utf8",
		stdio: "pipe",
	});
	console.log(check.trim());
} catch (error) {
	if (error && typeof error.stdout === "string" && error.stdout !== "") console.log(error.stdout.trim());
	if (error && typeof error.stderr === "string" && error.stderr !== "") console.error(error.stderr.trim());
	rmSync(work, { recursive: true, force: true });
	console.error("publish-sync: 脱敏检查或导出失败，发布仓未改动");
	process.exit(1);
}

// 4) 同步进发布仓（保留 .git）
for (const entry of readdirSync(PUBLISH)) {
	if (entry === ".git") continue;
	rmSync(join(PUBLISH, entry), { recursive: true, force: true });
}
for (const entry of readdirSync(work)) {
	cpSync(join(work, entry), join(PUBLISH, entry), { recursive: true });
}
rmSync(work, { recursive: true, force: true });

// 5) 提交 + tag
git(PUBLISH, ["add", "-A"]);
const staged = git(PUBLISH, ["status", "--porcelain"]).trim();
if (staged === "") {
	console.log("publish-sync: 内容无变化，跳过提交");
} else {
	git(PUBLISH, ["-c", "user.name=dsh-remote", "-c", "user.email=dsh-remote@local", "commit", "-m", `dsh-remote ${VERSION}`]);
	console.log(`publish-sync: 已提交 dsh-remote ${VERSION}`);
}
if (!flag("no-tag")) {
	git(PUBLISH, ["-c", "user.name=dsh-remote", "-c", "user.email=dsh-remote@local", "tag", "-f", "-a", `v${VERSION}`, "-m", `dsh-remote ${VERSION}`]);
	console.log(`publish-sync: 已打 tag v${VERSION}`);
}
console.log(`publish-sync: 发布仓 ${PUBLISH} @ ${git(PUBLISH, ["rev-parse", "--short", "HEAD"]).trim()}`);
